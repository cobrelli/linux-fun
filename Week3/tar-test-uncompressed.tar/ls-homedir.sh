#! /bin/bash
ls ~