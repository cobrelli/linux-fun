#! /bin/bash
ls -R ~tkt_cam/public_html/ | grep '201[1-9]/1[1-2]\|201[2-9]/\|^20111[1-2]\|^201[2-9]'
