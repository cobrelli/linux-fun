#! /bin/bash
ls -R ~tkt_cam/public_html/ | grep '.jpg'
