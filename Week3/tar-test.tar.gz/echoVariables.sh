#! /bin/bash
echo "$@"
